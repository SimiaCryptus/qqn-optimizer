use anyhow::Result;
use std::f64::consts::PI;

/// Trait defining an optimization problem interface
pub trait OptimizationProblem: Send + Sync {
    /// Get the problem name
    fn name(&self) -> &str;
    /// Get the problem dimension
    fn dimension(&self) -> usize;
    /// Get the initial starting point
    fn initial_point(&self) -> Vec<f64>;
    /// Evaluate the objective function at point x
    fn evaluate(&self, x: &[f64]) -> Result<f64>;
    /// Compute the gradient at point x
    fn gradient(&self, x: &[f64]) -> Result<Vec<f64>>;
    /// Get the optimal value if known
    fn optimal_value(&self) -> Option<f64>;
    /// Get convergence tolerance
    fn convergence_tolerance(&self) -> f64;
    /// Get problem bounds if any
    fn bounds(&self) -> Option<(Vec<f64>, Vec<f64>)>;
}
/// Rosenbrock function: f(x) = Σ[100(x_{i+1} - x_i²)² + (1 - x_i)²]
/// Global minimum: f(1, 1, ..., 1) = 0
#[derive(Debug, Clone)]
pub struct RosenbrockFunction {
    dimension: usize,
    name: String,
}
impl RosenbrockFunction {
    pub fn new(dimension: usize) -> Self {
        Self {
            dimension,
            name: format!("Rosenbrock_{}D", dimension),
        }
    }
}
impl OptimizationProblem for RosenbrockFunction {
    fn name(&self) -> &str {
        &self.name
    }
    fn dimension(&self) -> usize {
        self.dimension
    }
    fn initial_point(&self) -> Vec<f64> {
        vec![-1.2; self.dimension]
    }
    fn evaluate(&self, x: &[f64]) -> Result<f64> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }
        let mut sum = 0.0;
        for i in 0..self.dimension - 1 {
            let term1 = 100.0 * (x[i + 1] - x[i] * x[i]).powi(2);
            let term2 = (1.0 - x[i]).powi(2);
            sum += term1 + term2;
        }
        Ok(sum)
    }
    fn gradient(&self, x: &[f64]) -> Result<Vec<f64>> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }
        let mut grad = vec![0.0; self.dimension];
        for i in 0..self.dimension - 1 {
            // Gradient w.r.t. x[i]
            grad[i] += -400.0 * x[i] * (x[i + 1] - x[i] * x[i]) - 2.0 * (1.0 - x[i]);
            // Gradient w.r.t. x[i+1]
            grad[i + 1] += 200.0 * (x[i + 1] - x[i] * x[i]);
        }
        Ok(grad)
    }
    fn optimal_value(&self) -> Option<f64> {
        Some(0.0)
    }
    fn convergence_tolerance(&self) -> f64 {
        1e-6
    }
    fn bounds(&self) -> Option<(Vec<f64>, Vec<f64>)> {
        let lower = vec![-5.0; self.dimension];
        let upper = vec![10.0; self.dimension];
        Some((lower, upper))
    }
}
/// Rastrigin function: f(x) = A*n + Σ[x_i² - A*cos(2π*x_i)]
/// Global minimum: f(0, 0, ..., 0) = 0
#[derive(Debug, Clone)]
pub struct RastriginFunction {
    dimension: usize,
    a: f64,
    name: String,
}
impl RastriginFunction {
    pub fn new(dimension: usize) -> Self {
        Self {
            dimension,
            a: 10.0,
            name: format!("Rastrigin_{}D", dimension),
        }
    }
}
impl OptimizationProblem for RastriginFunction {
    fn name(&self) -> &str {
        &self.name
    }
    fn dimension(&self) -> usize {
        self.dimension
    }
    fn initial_point(&self) -> Vec<f64> {
        vec![2.0; self.dimension]
    }
    fn evaluate(&self, x: &[f64]) -> Result<f64> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }
        let n = self.dimension as f64;
        let sum: f64 = x
            .iter()
            .map(|&xi| xi * xi - self.a * (2.0 * PI * xi).cos())
            .sum();
        Ok(self.a * n + sum)
    }
    fn gradient(&self, x: &[f64]) -> Result<Vec<f64>> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }
        let grad: Vec<f64> = x
            .iter()
            .map(|&xi| 2.0 * xi + self.a * 2.0 * PI * (2.0 * PI * xi).sin())
            .collect();
        Ok(grad)
    }
    fn optimal_value(&self) -> Option<f64> {
        Some(0.0)
    }
    fn convergence_tolerance(&self) -> f64 {
        1e-4
    }
    fn bounds(&self) -> Option<(Vec<f64>, Vec<f64>)> {
        let lower = vec![-5.12; self.dimension];
        let upper = vec![5.12; self.dimension];
        Some((lower, upper))
    }
}
/// Sphere function: f(x) = Σx_i²
/// Global minimum: f(0, 0, ..., 0) = 0
#[derive(Debug, Clone)]
pub struct SphereFunction {
    dimension: usize,
    name: String,
}
impl SphereFunction {
    pub fn new(dimension: usize) -> Self {
        Self {
            dimension,
            name: format!("Sphere_{}D", dimension),
        }
    }
}
impl OptimizationProblem for SphereFunction {
    fn name(&self) -> &str {
        &self.name
    }
    fn dimension(&self) -> usize {
        self.dimension
    }
    fn initial_point(&self) -> Vec<f64> {
        vec![1.0; self.dimension]
    }
    fn evaluate(&self, x: &[f64]) -> Result<f64> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }
        let sum: f64 = x.iter().map(|&xi| xi * xi).sum();
        Ok(sum)
    }
    fn gradient(&self, x: &[f64]) -> Result<Vec<f64>> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }
        let grad: Vec<f64> = x.iter().map(|&xi| 2.0 * xi).collect();
        Ok(grad)
    }
    fn optimal_value(&self) -> Option<f64> {
        Some(0.0)
    }
    fn convergence_tolerance(&self) -> f64 {
        1e-8
    }
    fn bounds(&self) -> Option<(Vec<f64>, Vec<f64>)> {
        let lower = vec![-100.0; self.dimension];
        let upper = vec![100.0; self.dimension];
        Some((lower, upper))
    }
}
/// Beale function: f(x, y) = (1.5 - x + xy)² + (2.25 - x + xy²)² + (2.625 - x + xy³)²
/// Global minimum: f(3, 0.5) = 0
#[derive(Debug, Clone)]
pub struct BealeFunction {
    name: String,
}
impl BealeFunction {
    pub fn new() -> Self {
        Self {
            name: "Beale_2D".to_string(),
        }
    }
}
impl OptimizationProblem for BealeFunction {
    fn name(&self) -> &str {
        &self.name
    }
    fn dimension(&self) -> usize {
        2
    }
    fn initial_point(&self) -> Vec<f64> {
        vec![1.0, 1.0]
    }
    fn evaluate(&self, x: &[f64]) -> Result<f64> {
        if x.len() != 2 {
            return Err(anyhow::anyhow!("Beale function requires 2D input"));
        }
        let x1 = x[0];
        let x2 = x[1];
        let term1 = (1.5 - x1 + x1 * x2).powi(2);
        let term2 = (2.25 - x1 + x1 * x2 * x2).powi(2);
        let term3 = (2.625 - x1 + x1 * x2 * x2 * x2).powi(2);
        Ok(term1 + term2 + term3)
    }
    fn gradient(&self, x: &[f64]) -> Result<Vec<f64>> {
        if x.len() != 2 {
            return Err(anyhow::anyhow!("Beale function requires 2D input"));
        }
        let x1 = x[0];
        let x2 = x[1];
        let term1 = 1.5 - x1 + x1 * x2;
        let term2 = 2.25 - x1 + x1 * x2 * x2;
        let term3 = 2.625 - x1 + x1 * x2 * x2 * x2;
        let grad_x1 = 2.0 * term1 * (-1.0 + x2)
            + 2.0 * term2 * (-1.0 + x2 * x2)
            + 2.0 * term3 * (-1.0 + x2 * x2 * x2);
        let grad_x2 =
            2.0 * term1 * x1 + 2.0 * term2 * (2.0 * x1 * x2) + 2.0 * term3 * (3.0 * x1 * x2 * x2);
        Ok(vec![grad_x1, grad_x2])
    }
    fn optimal_value(&self) -> Option<f64> {
        Some(0.0)
    }
    fn convergence_tolerance(&self) -> f64 {
        1e-6
    }
    fn bounds(&self) -> Option<(Vec<f64>, Vec<f64>)> {
        let lower = vec![-4.5, -4.5];
        let upper = vec![4.5, 4.5];
        Some((lower, upper))
    }
}
/// Himmelblau function: f(x, y) = (x² + y - 11)² + (x + y² - 7)²
/// Global minima: f(3, 2) = f(-2.805118, 3.131312) = f(-3.779310, -3.283186) = f(3.584428, -1.848126) = 0
#[derive(Debug, Clone)]
pub struct HimmelblauFunction {
    name: String,
}
impl HimmelblauFunction {
    pub fn new() -> Self {
        Self {
            name: "Himmelblau_2D".to_string(),
        }
    }
}
impl OptimizationProblem for HimmelblauFunction {
    fn name(&self) -> &str {
        &self.name
    }
    fn dimension(&self) -> usize {
        2
    }
    fn initial_point(&self) -> Vec<f64> {
        vec![0.0, 0.0]
    }
    fn evaluate(&self, x: &[f64]) -> Result<f64> {
        if x.len() != 2 {
            return Err(anyhow::anyhow!("Himmelblau function requires 2D input"));
        }
        let x1 = x[0];
        let x2 = x[1];
        let term1 = (x1 * x1 + x2 - 11.0).powi(2);
        let term2 = (x1 + x2 * x2 - 7.0).powi(2);
        Ok(term1 + term2)
    }
    fn gradient(&self, x: &[f64]) -> Result<Vec<f64>> {
        if x.len() != 2 {
            return Err(anyhow::anyhow!("Himmelblau function requires 2D input"));
        }
        let x1 = x[0];
        let x2 = x[1];
        let grad_x1 = 2.0 * (x1 * x1 + x2 - 11.0) * (2.0 * x1) + 2.0 * (x1 + x2 * x2 - 7.0);
        let grad_x2 = 2.0 * (x1 * x1 + x2 - 11.0) + 2.0 * (x1 + x2 * x2 - 7.0) * (2.0 * x2);
        Ok(vec![grad_x1, grad_x2])
    }
    fn optimal_value(&self) -> Option<f64> {
        Some(0.0)
    }
    fn convergence_tolerance(&self) -> f64 {
        1e-6
    }
    fn bounds(&self) -> Option<(Vec<f64>, Vec<f64>)> {
        let lower = vec![-5.0, -5.0];
        let upper = vec![5.0, 5.0];
        Some((lower, upper))
    }
}
/// Booth function: f(x, y) = (x + 2y - 7)² + (2x + y - 5)²
/// Global minimum: f(1, 3) = 0
#[derive(Debug, Clone)]
pub struct BoothFunction {
    name: String,
}
impl BoothFunction {
    pub fn new() -> Self {
        Self {
            name: "Booth_2D".to_string(),
        }
    }
}
impl OptimizationProblem for BoothFunction {
    fn name(&self) -> &str {
        &self.name
    }
    fn dimension(&self) -> usize {
        2
    }
    fn initial_point(&self) -> Vec<f64> {
        vec![0.0, 0.0]
    }
    fn evaluate(&self, x: &[f64]) -> Result<f64> {
        if x.len() != 2 {
            return Err(anyhow::anyhow!("Booth function requires 2D input"));
        }
        let x1 = x[0];
        let x2 = x[1];
        let term1 = (x1 + 2.0 * x2 - 7.0).powi(2);
        let term2 = (2.0 * x1 + x2 - 5.0).powi(2);
        Ok(term1 + term2)
    }
    fn gradient(&self, x: &[f64]) -> Result<Vec<f64>> {
        if x.len() != 2 {
            return Err(anyhow::anyhow!("Booth function requires 2D input"));
        }
        let x1 = x[0];
        let x2 = x[1];
        let grad_x1 = 2.0 * (x1 + 2.0 * x2 - 7.0) + 2.0 * (2.0 * x1 + x2 - 5.0) * 2.0;
        let grad_x2 = 2.0 * (x1 + 2.0 * x2 - 7.0) * 2.0 + 2.0 * (2.0 * x1 + x2 - 5.0);
        Ok(vec![grad_x1, grad_x2])
    }
    fn optimal_value(&self) -> Option<f64> {
        Some(0.0)
    }
    fn convergence_tolerance(&self) -> f64 {
        1e-6
    }
    fn bounds(&self) -> Option<(Vec<f64>, Vec<f64>)> {
        let lower = vec![-10.0, -10.0];
        let upper = vec![10.0, 10.0];
        Some((lower, upper))
    }
}

/// Ackley function: f(x) = -a*exp(-b*sqrt(1/n * Σx_i²)) - exp(1/n * Σcos(c*x_i)) + a + e
/// Global minimum: f(0, 0, ..., 0) = 0
#[derive(Debug, Clone)]
pub struct AckleyFunction {
    dimension: usize,
    a: f64,
    b: f64,
    c: f64,
    name: String,
}
impl AckleyFunction {
    pub fn new(dimension: usize) -> Self {
        Self::with_parameters(dimension, 20.0, 0.2, 2.0 * PI)
    }
    pub fn with_parameters(dimension: usize, a: f64, b: f64, c: f64) -> Self {
        Self {
            dimension,
            a,
            b,
            c,
            name: format!("Ackley_{}D", dimension),
        }
    }
}
impl OptimizationProblem for AckleyFunction {
    fn name(&self) -> &str {
        &self.name
    }
    fn dimension(&self) -> usize {
        self.dimension
    }
    fn initial_point(&self) -> Vec<f64> {
        vec![1.0; self.dimension]
    }
    fn evaluate(&self, x: &[f64]) -> Result<f64> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }
        let n = self.dimension as f64;
        let sum_squares: f64 = x.iter().map(|&xi| xi * xi).sum();
        let sum_cos: f64 = x.iter().map(|&xi| (self.c * xi).cos()).sum();
        let term1 = -self.a * (-self.b * (sum_squares / n).sqrt()).exp();
        let term2 = -(sum_cos / n).exp();
        Ok(term1 + term2 + self.a + std::f64::consts::E)
    }
    fn gradient(&self, x: &[f64]) -> Result<Vec<f64>> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }
        let n = self.dimension as f64;
        let sum_squares: f64 = x.iter().map(|&xi| xi * xi).sum();
        let sqrt_term = (sum_squares / n).sqrt();
        let sum_cos: f64 = x.iter().map(|&xi| (self.c * xi).cos()).sum();
        let mut grad = vec![0.0; self.dimension];
        for i in 0..self.dimension {
            let xi = x[i];
            // First term derivative
            let term1_coeff = self.a * self.b * (-self.b * sqrt_term).exp() / (n * sqrt_term);
            let term1_deriv = term1_coeff * xi;
            // Second term derivative
            let term2_deriv = (sum_cos / n).exp() * self.c * (self.c * xi).sin() / n;
            grad[i] = term1_deriv + term2_deriv;
        }
        Ok(grad)
    }
    fn optimal_value(&self) -> Option<f64> {
        Some(0.0)
    }
    fn convergence_tolerance(&self) -> f64 {
        1e-4
    }
    fn bounds(&self) -> Option<(Vec<f64>, Vec<f64>)> {
        let lower = vec![-32.768; self.dimension];
        let upper = vec![32.768; self.dimension];
        Some((lower, upper))
    }
}
impl Default for BealeFunction {
    fn default() -> Self {
        Self::new()
    }
}
impl Default for HimmelblauFunction {
    fn default() -> Self {
        Self::new()
    }
}
impl Default for BoothFunction {
    fn default() -> Self {
        Self::new()
    }
}

// Add to src/benchmarks/functions.rs

/// Griewank function: f(x) = 1 + (1/4000)*Σx_i² - Π cos(x_i/√i)
/// Global minimum: f(0, 0, ..., 0) = 0
#[derive(Debug, Clone)]
pub struct GriewankFunction {
    dimension: usize,
    name: String,
}

impl GriewankFunction {
    pub fn new(dimension: usize) -> Self {
        Self {
            dimension,
            name: format!("Griewank_{}D", dimension),
        }
    }
}

impl OptimizationProblem for GriewankFunction {
    fn name(&self) -> &str {
        &self.name
    }

    fn dimension(&self) -> usize {
        self.dimension
    }

    fn initial_point(&self) -> Vec<f64> {
        vec![100.0; self.dimension] // Start far from optimum
    }

    fn evaluate(&self, x: &[f64]) -> Result<f64> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }

        let sum_squares: f64 = x.iter().map(|&xi| xi * xi).sum();
        let product: f64 = x
            .iter()
            .enumerate()
            .map(|(i, &xi)| (xi / ((i + 1) as f64).sqrt()).cos())
            .product();

        Ok(1.0 + sum_squares / 4000.0 - product)
    }

    fn gradient(&self, x: &[f64]) -> Result<Vec<f64>> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }

        let mut grad = vec![0.0; self.dimension];

        // Compute the product term for gradient calculation
        let product: f64 = x
            .iter()
            .enumerate()
            .map(|(i, &xi)| (xi / ((i + 1) as f64).sqrt()).cos())
            .product();

        for j in 0..self.dimension {
            let sqrt_j_plus_1 = ((j + 1) as f64).sqrt();

            // Gradient of sum_squares term
            grad[j] = x[j] / 2000.0;

            // Gradient of product term
            if product.abs() > 1e-15 {
                let sin_term = (x[j] / sqrt_j_plus_1).sin();
                grad[j] += (product / (x[j] / sqrt_j_plus_1).cos()) * sin_term / sqrt_j_plus_1;
            }
        }

        Ok(grad)
    }

    fn optimal_value(&self) -> Option<f64> {
        Some(0.0)
    }

    fn convergence_tolerance(&self) -> f64 {
        1e-4
    }

    fn bounds(&self) -> Option<(Vec<f64>, Vec<f64>)> {
        let lower = vec![-600.0; self.dimension];
        let upper = vec![600.0; self.dimension];
        Some((lower, upper))
    }
}

/// Schwefel function: f(x) = 418.9829*n - Σ x_i * sin(√|x_i|)
/// Global minimum: f(420.9687, 420.9687, ..., 420.9687) ≈ 0
#[derive(Debug, Clone)]
pub struct SchwefelFunction {
    dimension: usize,
    name: String,
}

impl SchwefelFunction {
    pub fn new(dimension: usize) -> Self {
        Self {
            dimension,
            name: format!("Schwefel_{}D", dimension),
        }
    }
}

impl OptimizationProblem for SchwefelFunction {
    fn name(&self) -> &str {
        &self.name
    }

    fn dimension(&self) -> usize {
        self.dimension
    }

    fn initial_point(&self) -> Vec<f64> {
        vec![100.0; self.dimension] // Start away from global optimum
    }

    fn evaluate(&self, x: &[f64]) -> Result<f64> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }

        let sum: f64 = x
            .iter()
            .map(|&xi| xi * (xi.abs().sqrt()).sin())
            .sum();

        Ok(418.9829 * self.dimension as f64 - sum)
    }

    fn gradient(&self, x: &[f64]) -> Result<Vec<f64>> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }

        let grad: Vec<f64> = x
            .iter()
            .map(|&xi| {
                if xi.abs() < 1e-15 {
                    0.0 // Avoid division by zero
                } else {
                    let sqrt_abs_xi = xi.abs().sqrt();
                    let sin_term = sqrt_abs_xi.sin();
                    let cos_term = sqrt_abs_xi.cos();

                    // d/dx [x * sin(√|x|)] = sin(√|x|) + x * cos(√|x|) * (1/(2√|x|)) * sign(x)
                    let derivative = sin_term + xi * cos_term * (0.5 / sqrt_abs_xi) * xi.signum();
                    -derivative // Negative because we're minimizing
                }
            })
            .collect();

        Ok(grad)
    }

    fn optimal_value(&self) -> Option<f64> {
        Some(0.0)
    }

    fn convergence_tolerance(&self) -> f64 {
        1e-3 // More lenient due to difficulty
    }

    fn bounds(&self) -> Option<(Vec<f64>, Vec<f64>)> {
        let lower = vec![-500.0; self.dimension];
        let upper = vec![500.0; self.dimension];
        Some((lower, upper))
    }
}

/// Levy function: f(x) = sin²(πw₁) + Σ(wᵢ-1)²[1+10sin²(πwᵢ+1)] + (wₙ-1)²[1+sin²(2πwₙ)]
/// where wᵢ = 1 + (xᵢ-1)/4
/// Global minimum: f(1, 1, ..., 1) = 0
#[derive(Debug, Clone)]
pub struct LevyFunction {
    dimension: usize,
    name: String,
}

impl LevyFunction {
    pub fn new(dimension: usize) -> Self {
        Self {
            dimension,
            name: format!("Levy_{}D", dimension),
        }
    }
}

impl OptimizationProblem for LevyFunction {
    fn name(&self) -> &str {
        &self.name
    }

    fn dimension(&self) -> usize {
        self.dimension
    }

    fn initial_point(&self) -> Vec<f64> {
        vec![2.0; self.dimension] // Start near but not at optimum
    }

    fn evaluate(&self, x: &[f64]) -> Result<f64> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }

        // Transform x to w
        let w: Vec<f64> = x.iter().map(|&xi| 1.0 + (xi - 1.0) / 4.0).collect();

        // First term
        let first_term = (PI * w[0]).sin().powi(2);

        // Middle terms
        let middle_sum: f64 = w[..w.len()-1]
            .iter()
            .map(|&wi| {
                let wi_minus_1_sq = (wi - 1.0).powi(2);
                let sin_term = (PI * wi + 1.0).sin().powi(2);
                wi_minus_1_sq * (1.0 + 10.0 * sin_term)
            })
            .sum();

        // Last term
        let last_w = w[w.len() - 1];
        let last_term = (last_w - 1.0).powi(2) * (1.0 + (2.0 * PI * last_w).sin().powi(2));

        Ok(first_term + middle_sum + last_term)
    }

    fn gradient(&self, x: &[f64]) -> Result<Vec<f64>> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }

        let w: Vec<f64> = x.iter().map(|&xi| 1.0 + (xi - 1.0) / 4.0).collect();
        let mut grad = vec![0.0; self.dimension];

        for i in 0..self.dimension {
            let wi = w[i];

            if i == 0 {
                // Gradient of first term
                grad[i] += 2.0 * (PI * wi).sin() * (PI * wi).cos() * PI * 0.25;
            }

            if i < self.dimension - 1 {
                // Gradient of middle terms
                let wi_minus_1 = wi - 1.0;
                let sin_term = (PI * wi + 1.0).sin();
                let cos_term = (PI * wi + 1.0).cos();

                let term1 = 2.0 * wi_minus_1 * (1.0 + 10.0 * sin_term.powi(2));
                let term2 = wi_minus_1.powi(2) * 20.0 * sin_term * cos_term * PI;

                grad[i] += (term1 + term2) * 0.25;
            }

            if i == self.dimension - 1 {
                // Gradient of last term
                let wi_minus_1 = wi - 1.0;
                let sin_2pi_wi = (2.0 * PI * wi).sin();
                let cos_2pi_wi = (2.0 * PI * wi).cos();

                let term1 = 2.0 * wi_minus_1 * (1.0 + sin_2pi_wi.powi(2));
                let term2 = wi_minus_1.powi(2) * 2.0 * sin_2pi_wi * cos_2pi_wi * 2.0 * PI;

                grad[i] += (term1 + term2) * 0.25;
            }
        }

        Ok(grad)
    }

    fn optimal_value(&self) -> Option<f64> {
        Some(0.0)
    }

    fn convergence_tolerance(&self) -> f64 {
        1e-5
    }

    fn bounds(&self) -> Option<(Vec<f64>, Vec<f64>)> {
        let lower = vec![-10.0; self.dimension];
        let upper = vec![10.0; self.dimension];
        Some((lower, upper))
    }
}

/// Zakharov function: f(x) = Σx_i² + (Σ(0.5*i*x_i))² + (Σ(0.5*i*x_i))⁴
/// Global minimum: f(0, 0, ..., 0) = 0
#[derive(Debug, Clone)]
pub struct ZakharovFunction {
    dimension: usize,
    name: String,
}

impl ZakharovFunction {
    pub fn new(dimension: usize) -> Self {
        Self {
            dimension,
            name: format!("Zakharov_{}D", dimension),
        }
    }
}

impl OptimizationProblem for ZakharovFunction {
    fn name(&self) -> &str {
        &self.name
    }

    fn dimension(&self) -> usize {
        self.dimension
    }

    fn initial_point(&self) -> Vec<f64> {
        vec![1.0; self.dimension]
    }

    fn evaluate(&self, x: &[f64]) -> Result<f64> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }

        let sum1: f64 = x.iter().map(|&xi| xi * xi).sum();
        let sum2: f64 = x
            .iter()
            .enumerate()
            .map(|(i, &xi)| 0.5 * (i + 1) as f64 * xi)
            .sum();

        Ok(sum1 + sum2.powi(2) + sum2.powi(4))
    }

    fn gradient(&self, x: &[f64]) -> Result<Vec<f64>> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }

        let sum2: f64 = x
            .iter()
            .enumerate()
            .map(|(i, &xi)| 0.5 * (i + 1) as f64 * xi)
            .sum();

        let grad: Vec<f64> = x
            .iter()
            .enumerate()
            .map(|(i, &xi)| {
                let coeff = 0.5 * (i + 1) as f64;
                2.0 * xi + 2.0 * sum2 * coeff + 4.0 * sum2.powi(3) * coeff
            })
            .collect();

        Ok(grad)
    }

    fn optimal_value(&self) -> Option<f64> {
        Some(0.0)
    }

    fn convergence_tolerance(&self) -> f64 {
        1e-6
    }

    fn bounds(&self) -> Option<(Vec<f64>, Vec<f64>)> {
        let lower = vec![-5.0; self.dimension];
        let upper = vec![10.0; self.dimension];
        Some((lower, upper))
    }
}

/// Michalewicz function: f(x) = -Σ sin(x_i) * sin²ᵐ(i*x_i²/π)
/// where m = 10 (steepness parameter)
/// Global minimum location depends on dimension
#[derive(Debug, Clone)]
pub struct MichalewiczFunction {
    dimension: usize,
    m: i32,
    name: String,
}

impl MichalewiczFunction {
    pub fn new(dimension: usize) -> Self {
        Self::with_steepness(dimension, 10)
    }

    pub fn with_steepness(dimension: usize, m: i32) -> Self {
        Self {
            dimension,
            m,
            name: format!("Michalewicz_{}D_m{}", dimension, m),
        }
    }
}

impl OptimizationProblem for MichalewiczFunction {
    fn name(&self) -> &str {
        &self.name
    }

    fn dimension(&self) -> usize {
        self.dimension
    }

    fn initial_point(&self) -> Vec<f64> {
        vec![PI / 4.0; self.dimension] // Start in middle of domain
    }

    fn evaluate(&self, x: &[f64]) -> Result<f64> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }

        let sum: f64 = x
            .iter()
            .enumerate()
            .map(|(i, &xi)| {
                let sin_xi = xi.sin();
                let inner_term = ((i + 1) as f64 * xi * xi / PI).sin();
                sin_xi * inner_term.powi(2 * self.m)
            })
            .sum();

        Ok(-sum)
    }

    fn gradient(&self, x: &[f64]) -> Result<Vec<f64>> {
        if x.len() != self.dimension {
            return Err(anyhow::anyhow!("Input dimension mismatch"));
        }

        let grad: Vec<f64> = x
            .iter()
            .enumerate()
            .map(|(i, &xi)| {
                let i_plus_1 = (i + 1) as f64;
                let sin_xi = xi.sin();
                let cos_xi = xi.cos();
                let inner_arg = i_plus_1 * xi * xi / PI;
                let sin_inner = inner_arg.sin();
                let cos_inner = inner_arg.cos();

                if sin_inner.abs() < 1e-15 {
                    return 0.0; // Avoid numerical issues
                }

                let term1 = cos_xi * sin_inner.powi(2 * self.m);
                let term2 = sin_xi * (2.0 * self.m as f64) * sin_inner.powi(2 * self.m - 1)
                    * cos_inner * (2.0 * i_plus_1 * xi / PI);

                -(term1 + term2)
            })
            .collect();

        Ok(grad)
    }

    fn optimal_value(&self) -> Option<f64> {
        // Known approximate global minima for some dimensions
        match self.dimension {
            2 => Some(-1.8013), // Approximate
            5 => Some(-4.687658), // Approximate
            10 => Some(-9.66015), // Approximate
            _ => None,
        }
    }

    fn convergence_tolerance(&self) -> f64 {
        1e-4
    }

    fn bounds(&self) -> Option<(Vec<f64>, Vec<f64>)> {
        let lower = vec![0.0; self.dimension];
        let upper = vec![PI; self.dimension];
        Some((lower, upper))
    }
}

